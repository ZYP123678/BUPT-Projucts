#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

void collatz_print(long N) {
    printf("Collatz: ");
    while(N != 1) {
        printf("%ld  ",N);
	    if(N % 2 == 0)	N = N / 2;
	    else		N = N * 3 + 1;
    }
    printf("1\n");
}

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Error: please input the file name and a positive integer\n");
	    return 0;
    }
    char *endptr;
    long N = strtol(argv[1], &endptr, 10);
    
    if(*endptr != '\0' || N <= 0) {
	    printf("Error: please input a positive integer\n");
	    return 0;
    }
    pid_t pid = fork();
    if(pid < 0) {
	    printf("fork failed\n");
	    return 0;
    }
    else if(pid == 0) {
	    collatz_print(N);
	    printf("Children exit\n");
    }
    else {
	    wait(NULL);
	    printf("Parents exit\n");
    }
    return 0;
}

