#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#include <fcntl.h>

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Error: please input the file name and a positive integer\n");
	    return 0;
    }
    char *endptr;
    long N = strtol(argv[1], &endptr, 10);
    
    if(*endptr != '\0' || N <= 0) {
	    printf("Error: please input a positive integer\n");
	    return 0;
    }

    char *shm_name = "/shared_memory";
    size_t shm_size = 4096;
    int shm_1 = shm_open(shm_name, O_CREAT | O_RDWR, 0666);
    if(shm_1 == -1) {
        printf("shm_open failed");
        return 0;
    }

    if(ftruncate(shm_1, shm_size) == -1) {
        printf("ftruncate failed");
        shm_unlink(shm_name);
        return 0;
    }

    char *shm_ptr = mmap(0, shm_size, PROT_WRITE | PROT_READ, MAP_SHARED, shm_1, 0);
    if(shm_ptr == MAP_FAILED) {
        printf("mmap failed");
        shm_unlink(shm_name);
        return 0;        
    }

    pid_t pid = fork();
    if(pid < 0) {
        printf("fork failed");
        munmap(shm_ptr, shm_size);
        shm_unlink(shm_name);
        return 0;
    }
    else if(pid == 0) {
        snprintf(shm_ptr, shm_size, "Collatz: ");
        char buffer[256];
        long current = N;
        while(current != 1) {
            snprintf(buffer, sizeof(buffer), "%ld, ", current);
            strncat(shm_ptr, buffer, shm_size - strlen(shm_ptr) - 1);
            if(current % 2 == 0)
                current = current /2;
            else
                current = 3 * current +1;
        }
        strncat(shm_ptr, "1\n", shm_size - strlen(shm_ptr) - 1);
        munmap(shm_ptr, shm_size);
        printf("Children exit\n");
        return 0;
    }
    else {
        wait(NULL);
        printf("%s", shm_ptr);
        munmap(shm_ptr, shm_size);
        shm_unlink(shm_name);
        printf("Parents exit\n");
    }
    return 0;
}
