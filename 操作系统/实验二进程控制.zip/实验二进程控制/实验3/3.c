#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <sys/wait.h>

#define BUFFER_SIZE 1024

int main() {
    int pipe1[2];//父到子
    int pipe2[2];//子到父
    pid_t pid;
    char write_msg[BUFFER_SIZE];
    char read_msg[BUFFER_SIZE];

    if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {
        printf("pipe 创建失败");
        return 0;
    }

    pid = fork();
    if(pid < 0) {
        printf("创建子进程失败");
        return 0;
    }
    else if(pid > 0) {
        close(pipe1[0]);//关闭父到子管道的读
        close(pipe2[1]);//关闭子到父管道的写

        printf("Input: ");
        fgets(write_msg, BUFFER_SIZE, stdin);

        size_t len = strlen(write_msg);
        if (write_msg[len - 1] == '\n') {
            write_msg[len - 1] = '\0';
        }

        if (write(pipe1[1], write_msg, strlen(write_msg) + 1) == -1) {
            printf("父进程写入失败");
            close(pipe1[1]);
            close(pipe2[0]);
            return 0;
        }

        close(pipe1[1]);

        if (read(pipe2[0], read_msg, BUFFER_SIZE) == -1) {
            printf("父进程读取失败");
            close(pipe2[0]);
            exit(EXIT_FAILURE);
        }

        printf("Answer: %s\n", read_msg);

        close(pipe2[0]);

        wait(NULL);
    } else {
        close(pipe1[1]);
        close(pipe2[0]);

        if(read(pipe1[0], read_msg, BUFFER_SIZE) == -1) {
            printf("子进程读取失败");
            close(pipe1[0]);
            close(pipe2[1]);
            return 0;
        }
        for(int i = 0; i < strlen(read_msg); i++) {
            if(read_msg[i] >= 'a' && read_msg[i] <= 'z') {
                read_msg[i] -=32;
            }
            else if(read_msg[i] >= 'A' && read_msg[i] <= 'Z') {
                read_msg[i] += 32;
            }
        }
        if (write(pipe2[1], read_msg, strlen(read_msg) + 1) == -1) {
            printf("子进程写入失败");
            close(pipe1[0]);
            close(pipe2[1]);
            return 0;
        }
    }
}
